export default [
  { name: 'original', value: 0 },
  { name: 'square', value: 1 },
  { name: 'banner', value: 7.8 },
  { name: '5 : 4', value: 1.25 },
  { name: '4 : 3', value: 1.33333 },
  { name: '6 : 4', value: 1.5 },
  { name: '16 : 9', value: 1.7777 }
];