export default [
  { name: 'big square', width: 600, height: 600, ratio: 1 },
  { name: 'middle square', width: 400, height: 400, ratio: 1 },
  { name: 'small square', width: 200, height: 200, ratio: 1 },
  { name: 'small size', width: 1200, height: 960, ratio: 1.25 },
  { name: 'better quality', width: 1920, height: 1536, ratio: 1.25 },
  { name: 'small size', width: 1200, height: 900, ratio: 1.33333 },
  { name: 'better quality', width: 1920, height: 1440, ratio: 1.33333 },
  { name: 'small size', width: 1200, height: 800, ratio: 1.5 },
  { name: 'better quality', width: 1920, height: 1280, ratio: 1.5 },
  { name: 'small size', width: 1200, height: 675, ratio: 1.7777 },
  { name: 'better quality', width: 1920, height: 1080, ratio: 1.7777 },
  { name: 'small banner', width: 468, height: 60, ratio: 7.8 },
  { name: 'big banner', width: 936, height: 120, ratio: 7.8 }
];