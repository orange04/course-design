import en from './en';
import fr from './fr';
import zhCN from './zh-cn';

export default {
    en,
    fr,
    'zh-cn': zhCN
}